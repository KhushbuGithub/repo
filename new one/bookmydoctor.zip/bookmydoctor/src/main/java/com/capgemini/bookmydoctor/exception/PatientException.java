package com.capgemini.bookmydoctor.exception;

public class PatientException extends RuntimeException {
	public PatientException(String message) {
		super(message);
	}
	

}
