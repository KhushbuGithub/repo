package com.capgemini.bookmydoctor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class BookmydoctorApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookmydoctorApplication.class, args);
	}

}
