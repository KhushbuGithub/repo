package com.capgemini.bookmydoctor.exception;

public class DoctorException extends RuntimeException {
	public DoctorException(String message) {
		super(message);
		
	}
	}
