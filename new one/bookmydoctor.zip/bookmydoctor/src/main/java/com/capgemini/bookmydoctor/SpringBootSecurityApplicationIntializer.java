package com.capgemini.bookmydoctor;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SpringBootSecurityApplicationIntializer extends AbstractSecurityWebApplicationInitializer {

}
