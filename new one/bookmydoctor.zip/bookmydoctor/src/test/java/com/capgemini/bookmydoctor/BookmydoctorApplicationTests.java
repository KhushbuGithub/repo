package com.capgemini.bookmydoctor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookmydoctorApplicationTests {

	@Test
	void contextLoads() {
	}

}
