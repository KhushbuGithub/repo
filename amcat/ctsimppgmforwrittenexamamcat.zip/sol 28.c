/*
 TESTCASE 1:
Input:
[2, 5, 8, 11, 3], 5
Expected Return Value:
[11, 11, 11, 11, 11]

TESTCASE 2:
Input:
[3, 2, 5, 8, 9, 11, 23, 45, 63], 9
Expected Return Value:
[63, 63, 63, 63, 63, 63, 63, 63, 63]
*/
int* maxReplace(int *arr, int len)
{
        int i, max;
        if(len>0)
        {
            max=arr[0];
            for(i=0;i<len;i++)
            {
                    if(max<arr[i])
                            max=arr[i];
            }
        }
        for(i=0;i<len;i++)
        arr[i]=max;
        return arr;
}

int main()
{
   // int arr[] = {23, 12, 14, 24, 21}, size, ctr;
 //  int arr[] = {1,1,1,1,1}, size, ctr;
 int arr[] = {1,2,3,4,5,6,7,8,9,10}, size, ctr;
    size = sizeof(arr) / sizeof(int);
    for(ctr = 0; ctr < size; ctr++)
         printf("%d ", arr[ctr]);
  maxReplace(arr, size);
     for(ctr = 0,printf("\n\n"); ctr < size; ctr++)
         printf("%d ", arr[ctr]);

    return 0;
}
