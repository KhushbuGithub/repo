/*This method countOccurance (int arr[], int value) of class occurrence
is supposed to return the count of occurrences of a number value in the
 input array arr. The function compiles successfully but fails to return the
 desired result due to logical errors.
Your task is to debug the program to pass all test cases.
*/

int Occurrence (int arr[], int len , int value)
        {
                int  i=0, count=0;
                while(i<len)
                {
                        if(arr[i]==value)
                                count++;
                                i++;
                }
                return count;
        }
int main()
{
   // int arr[] = {23, 12, 14, 24, 21}, size, ctr;
 //  int arr[] = {1,1,1,1,1}, size, ctr;
 int arr[] = {1,2,3,4,5,6,7,8,9,10,6,6}, size, ctr;
    size = sizeof(arr) / sizeof(int);
   printf("%d ", Occurrence(arr, size, 6));

    return 0;
}
