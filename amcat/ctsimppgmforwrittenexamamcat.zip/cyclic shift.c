#include<stdio.h>


char * cyclicShift(char str[])
{
int len=0, encrypt = 0, proc;
for(len = 0; str[len]; len++);
// while(str[len++]);
for(proc = len -1; proc>=0; proc--)
{
if(str[proc]!=' ')
{
     str[proc]+=encrypt;
     if(str[proc] > 122 )
         str[proc]-=26;
     encrypt++;
} else
{
    encrypt=0;
  //  while(str[proc]==' ')
}
}
return str;
}



int main()
{
char teststr[] = "yummy       food      gives     us zeal and zest";
printf("%s\n", teststr);
cyclicShift(teststr);
printf("%s\n", teststr);
return 0;
}
