#include<stdio.h>
#define ROWS 7
#define COLS 9

imgPrinter(int **img, int rows, int cols)
{
    int r, c;
    printf("\n");
    for(r = 0; r < rows; r++, printf("\n"))
        for(c=0; c< cols; c++)
          if(img[r][c] == 1)
               printf("%d", img[r][c]);
         else
            printf(" ");

}
imgRotate(int **img, int src_row, int src_col, int flag)
{
    int **trans_img = NULL, rctr, cctr, trans_row= src_col, trans_col=src_row;
    int start, end, temp, *tempPtr;
    trans_img = (int ** ) calloc(trans_row, sizeof(int *));

    for(rctr = 0; rctr < trans_row; rctr++)
         trans_img[rctr] = (int *) calloc(trans_col, sizeof(int));

         for(rctr = 0; rctr < src_row; rctr++)
              for(cctr =0; cctr < src_col; cctr++)
                   trans_img[cctr][rctr] = img[rctr][cctr];
    imgPrinter(trans_img, trans_row, trans_col);
if(flag == 0)
{
    for(rctr = 0;  rctr < trans_row; rctr++)
    {
        start = 0;
        end = trans_col - 1;
        while(start < end)
            {
                temp = trans_img[rctr][start];
                trans_img[rctr][start] = trans_img[rctr][end];
                trans_img[rctr][end]  = temp;
                start++;
                end--;

            }
    }
imgPrinter(trans_img, trans_row, trans_col);
}
    else
    {
        start = 0;
        end = trans_row - 1;
        while(start < end)
            {
                tempPtr = trans_img[start];
                trans_img[start] = trans_img[end];
                trans_img[end]  = tempPtr;
                start++;
                end--;

            }
            imgPrinter(trans_img, trans_row, trans_col);
    }










}
int main()
{
int image[7][9] = {
                                    {0,0,0,0,1,0,0,0,0},
                                    {0,0,0,1,0,1,0,0,0},
                                    {0,0,1,0,0,0,1,0,0},
                                    {0,1,0,0,0,0,0,1,0},
                                    {1,0,1,0,1,0,1,0,1},
                                    {1,0,0,0,0,0,0,0,1},
                                    {1,0,0,0,0,0,0,0,1}
                                   };
      int ** src_img=NULL, row, col, rctr, cctr;
       src_img = (int ** ) calloc(ROWS, sizeof(int *));
       for(rctr = 0; rctr < ROWS; rctr++)
                                src_img[rctr] = (int *) calloc(COLS, sizeof(int));
       for(rctr = 0;rctr < ROWS; rctr++)
           for(cctr = 0; cctr < COLS; cctr++)
                src_img[rctr][cctr] = image[rctr][cctr];


             imgRotate(src_img, ROWS, COLS, 1);
                                   return 0;
                                   }
