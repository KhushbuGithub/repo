/*
The method manchester (int arr) of class signal accepts an array arr as
an input. Each element of arr represents a bit 0 or 1. The output is an array
 with the following property for each element in the input array arr. If the
 bit arr[i] is the same as arr[i-1], then the element of the output array is 0,
 iIf they are different then its 1. For the first bit in the input array , assume
  its previous bit to be 0. This encoding is stored and returned in a new
  array.For e.g if arr is {0, 1, 0, 0, 1, 1, 1, 0}  the function should return
  an array {0, 1, 1, 0, 1, 0, 0, 1}.
The function compiles successfully but fails to return the desired result
due to logical errors.Your task is to debug the program to pass
all test cases.

 TESTCASE 1:
Input:
[1, 1, 0, 0, 1, 0]
Expected Return Value:
[1, 0, 1, 0, 1, 1]
TESTCASE 2:
Input:
[0, 0, 0, 1, 0, 1, 1, 1]
Expected Return Value:
[0, 0, 0, 1, 1, 1, 0
*/


 int * manchester(int arr[], int len)
    {

            int *res=(int *)malloc(sizeof(int )* len);
            int  result,i;
            res[0]=arr[0];
            for( i=1;i<len;i++)
            {
                 //   result=(arr[i]==arr[i-1]);
               //     res[i]=(result)?0:1;
               res[i] = !(arr[i]==arr[i-1]);
            }
            return res;
    }

int main()
{
     int inp[] = {0, 0, 0, 1, 0, 1, 1, 1}, size, *res, ctr;
     size = sizeof(inp)/sizeof(inp[0]);
     for(ctr =0; ctr < size; ctr++)
         printf("%d ", inp[ctr]);
     res = manchester(inp, size);
      for(ctr  = 0, printf("\n\n"); ctr < size; ctr++)
         printf("%d ", res[ctr]);
}










