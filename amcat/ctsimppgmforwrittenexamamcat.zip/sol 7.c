#include<stdio.h>


int main ()
    {
    int  num;
    num=40;
        switch (num)
        {
            case 1:
            printf("red"); break;
            case 2:
                  printf("black"); break;
            case 3:
           printf("white"); break;
            case 4:
              printf("green"); break;
            default:
                    printf("no color");
            break;
        }
    }

