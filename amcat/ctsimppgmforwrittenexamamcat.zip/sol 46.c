/*
TESTCASE 1:
Input:
[-2, -4, -3, -5, -6, -7, -8], 7, 3
Expected Return Value:
0
TESTCASE 2:
Input:
[22, 55, 66, 33, 44, 77], 6,13
Expected Return Value:
5
*/
int countElement(int arr[],int len,int n)
{
        int i,count=0;
        for( i=0;i<len;i++)
        {
                if(arr[i]>(2*n))

                count+=1;
        }
return count;
}


int main()
{
   // int arr[] = {23, 12, 14, 24, 21}, size, ctr;
 //  int arr[] = {1,1,1,1,1}, size, ctr;
 int arr[] = {1,2,13,4,5,6,17,8,9,10,6,6}, size, ctr;
    size = sizeof(arr) / sizeof(int);
   printf("%d ", countElement(arr, size, 3));

    return 0;
}
