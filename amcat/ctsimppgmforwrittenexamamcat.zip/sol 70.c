#include<stdio.h>



int* sortArray(int arr[], int len)
{
int small,pos,i,j,temp;
for(i=0;i<=len-1;i++)
{
for(j=i;j<len;j++)
{
temp=0;
if(arr[i]>arr[j])
{
temp=arr[i];
arr[i]=arr[j];
arr[j] = temp;
}
}
}
return  arr;
}
int main()
{
   // int arr[] = {23, 12, 14, 24, 21}, size, ctr;
 //  int arr[] = {1,1,1,1,1}, size, ctr;
 int arr[] = {12,11,45,67,10,90,77,42,24}, size, ctr;
    size = sizeof(arr) / sizeof(int);
    for(ctr = 0; ctr < size; ctr++)
         printf("%d ", arr[ctr]);
    sortArray(arr, size);
     for(ctr = 0,printf("\n\n"); ctr < size; ctr++)
         printf("%d ", arr[ctr]);

    return 0;
}

