#include<stdio.h>

int calculationmatrixsum(int **matrix,int m, int n)
{
    int i, j , sum=0,row=m,column = n;
    if((row>0)&&(column>0))
    {
        for(i=0;i<row;i++)
        {
      //      sum = 0;
            for(j=0;j<column;j++)
            {
                if(i==j)
                {
                    if(matrix[i][j]%2!=0)
                            sum += matrix[i][i];
                }
            }
        }
        return sum;
    }
    else return sum;
}

int main()
{
int r, c, rows, cols, rctr, cctr, values = 11;
int  **matrix = NULL;
scanf("%d %d", &r, &c);
for(rctr = 0; rctr < r; rctr++)
   matrix =   (int **)   malloc(sizeof(int *) * r);

   for(rctr = 0; rctr < r; rctr++)
     matrix[rctr] = (int *)    malloc(sizeof(int) * c);

     for(rctr = 0;rctr < r; rctr++)
         for(cctr = 0; cctr < c; cctr++)
            matrix[rctr][cctr] = values++;

printf("%d", calculationmatrixsum(matrix, r, c) );
return 0;
}
