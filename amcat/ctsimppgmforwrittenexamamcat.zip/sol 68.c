#include<stdio.h>



 int sameElementCount(int arr[], int len)
{
int i,count=0;
 for(i=0;i<len-1;i++)
{
if((arr[i]%2==0)&&(arr[i]==arr[i+1]))
count++;
}
return  count;
}

int main()
{
int arr[] = {1,1,4,4,5,5,5,5,6,6,7,7,7,7,7,7,8,8,8,8};
int size;
size = sizeof(arr) / sizeof(int);
printf("%d ", sameElementCount(arr, size));
return 0;

}
