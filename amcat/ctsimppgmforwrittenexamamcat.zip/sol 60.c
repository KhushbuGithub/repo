/*Problem
The method  sortArray(int arr[]) of class Selection sort an integer array arr as input and perform an in place selection sort .The function an input array sorted as ascending order
The function compiles fine but to return desired results for some cases
Your task to fix  the code so but that it passes at test cases
Assumption:
In this particular implementation sort the smallest elements in the array is swapped with the elements of the next index and so on
Program
*/

int * sortArray(int arr[], int len)
{
int x=0,y=0,n=len;
for(x=0;x<n;x++)
{
int index_of_min = x;
for(y=x;y<n;y++)
{
if(arr[index_of_min]>arr[y])
{
index_of_min=y;
}
}
int temp=arr[x];
arr[x]=arr[index_of_min];
arr[index_of_min]=temp;
}
return  arr;
}

int main()
{
    //int arr[] = {23, 12, 14, 24, 21}, size, ctr;
 //  int arr[] = {1,1,1,1,1}, size, ctr;
 int arr[] = {10,9,8,7,6,5,4,3,2,1}, size, ctr;
    size = sizeof(arr) / sizeof(int);
    for(ctr = 0; ctr < size; ctr++)
         printf("%d ", arr[ctr]);
    sortArray(arr, size);
     for(ctr = 0,printf("\n\n"); ctr < size; ctr++)
         printf("%d ", arr[ctr]);

    return 0;
}

