/*
TESTCASE 1:
Input:
[1, 2, 3, 4, 5, 6, 7]
Expected Return Value:
[7, 6, 5, 4, 3, 2, 1]
TESTCASE 2:
Input:
[2, 8, 4, 6]
Expected Return Value:
[6, 4,8, 2]
*/

 int * reverseArray(int arr[], int len)
        {
                        int i, temp, orginallen=len;
                    //    int len=orginallen;
                        for(i=0;i<orginallen/2;i++)
                        {
                                    temp=arr[len-1];
                                    arr[len-1]=arr[i];
                                    arr[i]=temp;
                                    len-=1;
                        }
                        return arr;
        }

int main()
{
   // int arr[] = {23, 12, 14, 24, 21}, size, ctr;
 //  int arr[] = {1,1,1,1,1}, size, ctr;
 int arr[] = {1,2,3,4,5,6,7,8,9,10}, size, ctr;
    size = sizeof(arr) / sizeof(int);
    for(ctr = 0; ctr < size; ctr++)
         printf("%d ", arr[ctr]);
    reverseArray(arr, size);
     for(ctr = 0,printf("\n\n"); ctr < size; ctr++)
         printf("%d ", arr[ctr]);

    return 0;
}
