#include<stdio.h>

int paranthesesChecker(char str[])
{
int index, check, count=0;
for(index = 0; str[index] && check >= 0;  index++)
{
if(str[index] == '(')
   {check++; count++;}
    else check--;
}
if(check <=0 || check !=0) return -1;
return count;
}
int main()
{
char teststr[] = "(()())(()()";
printf("%d", paranthesesChecker(teststr));
}
