#include<stdio.h>
#include<malloc.h>

int * bombDiffuser(int arr[], int len, int key)
{

int inner, outer, *newarr, ctr;
newarr = (int *) calloc(len, sizeof(int));

for(outer = 0; outer < len; outer++)
   for(inner = outer + 1, ctr=0; ctr < key;ctr++, inner++)
   {
       if(inner >= len) inner=0;
        newarr[outer] += arr[inner];
   }
   //    newarr[outer] += arr[inner % (len)];

return newarr;
}

int main()
{
int arr[]= {4,2,-5,11},ctr, size, *newarr;
size = sizeof(arr) / sizeof(int);
    for(ctr = 0; ctr < size; ctr++)
         printf("%d ", arr[ctr]);
    newarr = bombDiffuser(arr, size, 3);
     for(ctr = 0,printf("\n\n"); ctr < size; ctr++)
         printf("%d ", newarr[ctr]);
return 0;
}
