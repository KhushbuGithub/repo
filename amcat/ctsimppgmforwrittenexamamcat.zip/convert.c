#include<stdio.h>
#include<stdlib.h>
//#define DEBUG
// 2:48 2: 55 3: 05
isOccuring(int num,  int digit)
{
    int myDigit;
    while(num)
    {
        myDigit =  num % 10;
        if(myDigit == digit) break;
        num = num / 10;
    }
    if(num) return 1;
    return 0;
}

int convert(int num, int digs)
{
int num_len= 0, safe, rem_digs, zero_flag, result = 0, ctr, gotit, power;
safe = num;
while(num)
{
 num = num / 10;
 num_len++;
}
num = safe;
rem_digs = num_len - digs;
#ifdef DEBUG
printf("rem_digs = %d \n", rem_digs);
#endif // DEBUG

zero_flag = isOccuring(num, 0);
if(zero_flag == 1)
rem_digs--;
for(ctr = 1; ctr <=9 && gotit < rem_digs; ctr++)
{
    if( isOccuring(num, ctr) == 1)
    {
        result = result * 10 + ctr;
        gotit++;
    }
}
if(zero_flag == 1)
{
    rem_digs-=2;
    power = pow(10, rem_digs);
    power*=10;
    result= ((result / power) * 10 * power) + result % power;
}
return result;
}
int main()
{
int num = 24809516, remov_dig= 4;
printf("%d",convert(num, remov_dig));
return 0;
}
