/*You are required to fix all logical errors in the given code. You can click on
Compile &amp; Run anytime to check the compilation/execution status of the
program. You can use System.out.println to debug your code. The submitted
code should be logically/syntactically correct and pass all test cases. Do not
write the main() function as it is not required.
Code Approach: For this question, you will need to correct the given
implementation  We do not expect you to modify the approach or incorporate
any additional library methods.
The function sortArray(int * arr,int len) accepts an integer array
arr of  length (len>0) as an input and perform an in place sort operation
on it. The function is expected to return the input array sorted in
 descending order The function compiles successfully but fails to return
 the desired results due to logical  errors
Your task is to debug the program to pass all the test cases
TESTCASE 1:
Input:
[23, 12, 14, 24, 21], 5
Expected Return Value:
[24, 23, 21, 14, 12]

TESTCASE 2:
Input:
[1, 1, 1, 1, 1], 5
Expected Return Value:
[1, 1, 1, 1, 1]
*/
int * sortArray(int *arr,int len )
{
        int  i,max,location,j,temp;
        for(i=0;i<len;i++)
        {
            max=arr[i];
            location=i;
            for(j=i+1;j<len;j++)
            {
                    if(max<arr[j])
                    {
                            max=arr[j];
                            location=j;
                    }
            }
            temp=arr[location];
            arr[location]=arr[i];
            arr[i]=temp;
            }
            return arr;
        }


int main()
{
   // int arr[] = {23, 12, 14, 24, 21}, size, ctr;
 //  int arr[] = {1,1,1,1,1}, size, ctr;
 int arr[] = {1,2,3,4,5,6,7,8,9,10}, size, ctr;
    size = sizeof(arr) / sizeof(int);
    for(ctr = 0; ctr < size; ctr++)
         printf("%d ", arr[ctr]);
    sortArray(arr, size);
     for(ctr = 0,printf("\n\n"); ctr < size; ctr++)
         printf("%d ", arr[ctr]);

    return 0;
}
